#!/bin/bash
# Uso: DADOS=/caminho/dos/paineis bash executar.sh
set -e
for s in 01_pipeline_sem_vazamento 02_inferencia_bootstrap 03_metricas_probabilidade 04_entradas_e_saidas \
         05_robustez_e_calendario 06_consolidacao 07_complementos 08_definicoes_de_evento \
         09_decomposicao_por_tipo; do
  echo "== $s"; python3 $s.py
done
echo "== 10_corte_temporal"; python3 10_corte_temporal.py "${ANO_CORTE:-2023}"
